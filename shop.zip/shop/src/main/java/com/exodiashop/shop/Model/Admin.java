package com.exodiashop.shop.Model;

import org.springframework.stereotype.Component;

@Component
public class Admin extends User{
    public Admin(){

    }

}
